const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))


// slider javascript
$(document).ready(function(){
  
    $('.promotionalslider_wrapper').slick({
      infinite: true,            // Enable looping
      slidesToShow: 5,
      slidesToScroll: 1,
      autoplay: true,            // Enable autoplay
      autoplaySpeed: 3000,       // Set autoplay interval (3 seconds)
      responsive: [
        {
          breakpoint: 768,
          settings: {
              slidesToShow: 2,
              slidesToScroll: 2,
              autoplay: true,
              autoplaySpeed: 3000,
          }
        }
      ]
    });
  });
  